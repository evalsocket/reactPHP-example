<?php

namespace React\Tests\Stream;

class CallableStub
{
    public function __invoke()
    {
    }
}
